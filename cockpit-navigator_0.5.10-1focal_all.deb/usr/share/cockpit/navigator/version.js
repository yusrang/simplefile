export let NAVIGATOR_VERSION = " 0.5.10-1focal";
